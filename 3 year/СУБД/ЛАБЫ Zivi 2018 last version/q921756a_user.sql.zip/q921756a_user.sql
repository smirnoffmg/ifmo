-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Мар 21 2018 г., 10:22
-- Версия сервера: 5.7.20-19-beget-5.7.20-20-1-log
-- Версия PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `q921756a_user`
--

-- --------------------------------------------------------

--
-- Структура таблицы `clientDB`
--
-- Создание: Мар 13 2018 г., 17:21
--

DROP TABLE IF EXISTS `clientDB`;
CREATE TABLE `clientDB` (
  `ID Client` int(20) NOT NULL,
  `Family` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Name` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Othestvo` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Telephon` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `clientDB`
--

INSERT INTO `clientDB` (`ID Client`, `Family`, `Name`, `Othestvo`, `Address`, `Telephon`) VALUES
(1, 'Петров', 'Сергей', 'Петрович', 'Ул. Ленина', 91134252),
(2, 'Артемова', 'Елена', 'Николаевна', 'ул.Чайковского', 91156787),
(3, 'Иванова', 'Юлия', 'Сергеевна', 'ул.Советская', 91156868),
(4, 'Егорова', 'Любовь', 'Викторовна', 'ул.Гданьская', 91156969),
(5, 'Гущина', 'Ирина ', 'Витальевна', 'ул.Хоперская', 91157070);

-- --------------------------------------------------------

--
-- Структура таблицы `ClientLog`
--
-- Создание: Мар 13 2018 г., 16:46
--

DROP TABLE IF EXISTS `ClientLog`;
CREATE TABLE `ClientLog` (
  `LogID` int(11) NOT NULL,
  `employeeID` int(8) NOT NULL,
  `ID Client` int(20) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `Time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `ClientLog`
--

INSERT INTO `ClientLog` (`LogID`, `employeeID`, `ID Client`, `Date`, `Time`) VALUES
(123, 4, 2, '2017-11-01', '01:00:00'),
(124, 5, 4, '2017-05-07', '02:00:00'),
(125, 5, 5, '2018-09-12', '12:00:00'),
(126, 2, 1, '2018-02-23', '15:00:00'),
(127, 2, 3, '2018-03-24', '08:00:08');

-- --------------------------------------------------------

--
-- Структура таблицы `employeePD`
--
-- Создание: Мар 13 2018 г., 15:56
--

DROP TABLE IF EXISTS `employeePD`;
CREATE TABLE `employeePD` (
  `employeeID` int(8) NOT NULL,
  `Family` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Othestvo` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Telephon` int(11) NOT NULL,
  `Position` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `employeePD`
--

INSERT INTO `employeePD` (`employeeID`, `Family`, `Name`, `Othestvo`, `Telephon`, `Position`) VALUES
(1, 'Проводков', 'Генадий', 'Владимирович', 912452593, 'Админ'),
(2, 'Артемова', 'Юлия', 'Владимировна', 901498323, 'Кадровик'),
(3, 'Семенова', 'Елена', 'Витальевна', 904232595, 'Кадровик'),
(4, 'Ломоносов', 'Роман', 'Петрович', 903344456, 'Бухгалтер'),
(5, 'Петрова', 'Валентина', 'Николаевна', 911546577, 'Фин директор'),
(6, 'Иванова', 'Надежда', 'Андреевна', 921483647, 'Охранник');

-- --------------------------------------------------------

--
-- Структура таблицы `PriceClientLog`
--
-- Создание: Мар 13 2018 г., 17:03
--

DROP TABLE IF EXISTS `PriceClientLog`;
CREATE TABLE `PriceClientLog` (
  `serviceID` int(11) NOT NULL,
  `LogID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `PriceClientLog`
--

INSERT INTO `PriceClientLog` (`serviceID`, `LogID`) VALUES
(12, 123),
(13, 124),
(14, 125),
(15, 126),
(16, 127);

-- --------------------------------------------------------

--
-- Структура таблицы `Pricelist`
--
-- Создание: Мар 13 2018 г., 16:42
--

DROP TABLE IF EXISTS `Pricelist`;
CREATE TABLE `Pricelist` (
  `serviceID` int(11) NOT NULL,
  `price` int(10) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `Pricelist`
--

INSERT INTO `Pricelist` (`serviceID`, `price`, `description`) VALUES
(12, 150000, 'Постоянное обслуживание объекта'),
(13, 20000, 'Установка кабеля с изоляцией'),
(14, 80000, 'Прокладка труб рядом с кабелем'),
(15, 10000, 'Изготовление деталей из металла'),
(16, 50000, 'Подготовка инструментов');

-- --------------------------------------------------------

--
-- Структура таблицы `PriceMaterial`
--
-- Создание: Мар 13 2018 г., 17:02
--

DROP TABLE IF EXISTS `PriceMaterial`;
CREATE TABLE `PriceMaterial` (
  `serviceID` int(11) NOT NULL,
  `IDMaterial` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;

--
-- Дамп данных таблицы `PriceMaterial`
--

INSERT INTO `PriceMaterial` (`serviceID`, `IDMaterial`) VALUES
(12, 1),
(13, 2),
(14, 3),
(15, 4),
(16, 5),
(12, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `security_user`
--
-- Создание: Мар 13 2018 г., 09:50
--

DROP TABLE IF EXISTS `security_user`;
CREATE TABLE `security_user` (
  `id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL,
  `rights` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `security_user`
--

INSERT INTO `security_user` (`id`, `login`, `password`, `rights`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'a:8:{i:1;i:3;i:2;i:3;i:3;i:3;i:4;i:3;i:5;i:3;i:6;i:3;i:7;i:3;i:8;i:3;}'),
(2, 'user1', '21232f297a57a5a743894a0e4a801fc3', 'a:8:{i:1;i:3;i:2;i:3;i:3;i:2;i:4;i:2;i:5;i:2;i:6;i:2;i:7;i:2;i:8;i:2;}'),
(3, 'user2', '21232f297a57a5a743894a0e4a801fc3', 'a:8:{i:1;i:2;i:2;i:2;i:3;i:2;i:4;i:0;i:5;i:2;i:6;i:0;i:7;i:0;i:8;i:0;}');

-- --------------------------------------------------------

--
-- Структура таблицы `Supply`
--
-- Создание: Мар 13 2018 г., 15:38
--

DROP TABLE IF EXISTS `Supply`;
CREATE TABLE `Supply` (
  `IDMaterial` int(11) NOT NULL,
  `Name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(20) NOT NULL,
  `SupplyName` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Production` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;

--
-- Дамп данных таблицы `Supply`
--

INSERT INTO `Supply` (`IDMaterial`, `Name`, `price`, `SupplyName`, `Production`) VALUES
(1, 'Кабель', 1500, 'ООО \"КабельДела', 'ООО \"Кабель Про'),
(2, 'Металл', 1000, 'ОАО \"МеталлСтро', 'ОАО \"Дешевый Ме'),
(3, 'Трубы', 300, 'ПАО \"ТрубыВари\"', 'ПАО \"Трубы\"'),
(4, 'Изоляция', 500, 'ООО \"ИзолируйВс', 'ОАО \"Резина\"'),
(5, 'Инструменты', 2300, 'ЗАО \"Ремонт\"', 'ЗАО \"Инструмент');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `clientDB`
--
ALTER TABLE `clientDB`
  ADD PRIMARY KEY (`ID Client`);

--
-- Индексы таблицы `ClientLog`
--
ALTER TABLE `ClientLog`
  ADD PRIMARY KEY (`LogID`),
  ADD KEY `ID сотрудник` (`employeeID`),
  ADD KEY `ID Client` (`ID Client`);

--
-- Индексы таблицы `employeePD`
--
ALTER TABLE `employeePD`
  ADD PRIMARY KEY (`employeeID`);

--
-- Индексы таблицы `PriceClientLog`
--
ALTER TABLE `PriceClientLog`
  ADD KEY `ID Zapisi` (`LogID`),
  ADD KEY `Uslugi-Zapis_ibfk_2` (`serviceID`);

--
-- Индексы таблицы `Pricelist`
--
ALTER TABLE `Pricelist`
  ADD PRIMARY KEY (`serviceID`);

--
-- Индексы таблицы `PriceMaterial`
--
ALTER TABLE `PriceMaterial`
  ADD KEY `Uslugi-Rash_ibfk_1` (`IDMaterial`),
  ADD KEY `serviceID` (`serviceID`) USING BTREE;

--
-- Индексы таблицы `security_user`
--
ALTER TABLE `security_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Индексы таблицы `Supply`
--
ALTER TABLE `Supply`
  ADD PRIMARY KEY (`IDMaterial`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `ClientLog`
--
ALTER TABLE `ClientLog`
  MODIFY `LogID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
